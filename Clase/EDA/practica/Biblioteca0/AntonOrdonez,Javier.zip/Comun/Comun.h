#ifndef NCOMUN
    #define NCOMUN

// Includes de las librerías estándar de C
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <string.h>

//Include de Curses
#include <ncursesw/curses.h>

#endif